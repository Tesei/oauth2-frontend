# Использование @fun-sun/ui-kit как npm пакета

## Сборка пакета

Для сборки npm пакета выполните команду:

```bash
npm run build:package
```

Эта команда:

1. Очистит предыдущую сборку
2. Соберет библиотеку с помощью Vite
3. Сгенерирует TypeScript типы
4. Создаст готовый к публикации пакет в папке `dist/`

## Публикация пакета

### Локальная публикация (для тестирования)

```bash
# Создать .tgz файл пакета
npm pack

# Установить пакет локально в другом проекте
npm install ./fun-sun-vue-components-your-version-package.tgz
```

### Публикация в npm registry

Происходит при регистрации нового тэга в репозитории. Пакет публикуется в приватный реестр Nexus.

## Использование в проекте

### Установка

```bash
npm install @fun-sun/ui-kit
```

### Импорт компонентов

#### Импорт всех компонентов и утилит

```javascript
import { BaseButton, BaseInput, debounce } from '@fun-sun/ui-kit'
```

#### Импорт только компонентов (tree shaking)

```javascript
import { BaseButton, BaseInput } from '@fun-sun/ui-kit/components'
```

#### Импорт только утилит (tree shaking)

```javascript
import { debounce, onlyCyrillicLettersMask } from '@fun-sun/ui-kit/utils'
```

#### Импорт директив (tree shaking)

```javascript
import { vOutside } from '@fun-sun/ui-kit/directives'
```

#### Импорт стилей

**⚠️ Важно:** Для корректного отображения компонентов необходимо подключить стили пакета.

##### Автоматическое подключение (Vite)

При использовании Vite или другого современного бандлера стили могут автоматически подключаться при импорте компонентов. Однако для гарантированной работы рекомендуется явно импортировать стили.

##### Явное подключение стилей (рекомендуется)

Добавьте импорт стилей в главный файл вашего приложения (например, `main.js`, `main.ts`, `app.vue` или `nuxt.config.ts`):

**Для Vite/Vue 3:**

```javascript
// main.js или main.ts
import '@fun-sun/ui-kit/vue-components.css'
```

**Для Nuxt 3:**

```javascript
// nuxt.config.ts
export default defineNuxtConfig({
    css: ['@fun-sun/ui-kit/vue-components.css'],
})
```

**Для Vue 2 или других бандлеров:**

```javascript
// В главном файле приложения
import '@fun-sun/ui-kit/vue-components.css'
```

**Альтернативный способ (прямой путь к файлу):**

```javascript
// Если импорт через пакет не работает
import '@fun-sun/ui-kit/dist/assets/vue-components.css'
```

##### Проверка подключения стилей

После подключения стилей компоненты должны отображаться с правильным оформлением. Если стили не применяются:

1. Убедитесь, что импорт стилей добавлен в главный файл приложения
2. Проверьте, что путь к CSS файлу корректен
3. Убедитесь, что бандлер обрабатывает CSS импорты
4. Проверьте консоль браузера на наличие ошибок загрузки стилей

**Примечание:** Пакет также зависит от `@fun-sun/ui-tokens` для переменных и базовых стилей. Убедитесь, что этот пакет установлен и его стили подключены, если это требуется вашим проектом.

### Использование в Vue приложении

```vue
<template>
    <div>
        <BaseButton @click="handleClick"> Нажми меня </BaseButton>
        <BaseInput v-model="inputValue" />
        <BaseIcon :icon="SearchIcon" />
    </div>
</template>

<script setup>
import { BaseButton, BaseInput, BaseIcon } from '@fun-sun/ui-kit/components'
import SearchIcon from '@fun-sun/ui-tokens/assets/icons/search/normal-1.svg'
import { ref } from 'vue'

const inputValue = ref('')
const handleClick = () => {
    console.log('Кнопка нажата!')
}
</script>
```

**Примечание:** Компонент **BaseIcon** принимает SVG-компонент, импортированный через `vite-svg-loader`. Иконки доступны в пакете `@fun-sun/ui-tokens`.

## Tree Shaking

Пакет поддерживает tree shaking, что означает, что в финальный бандл попадут только те компоненты и утилиты, которые вы действительно импортируете и используете.

### Рекомендуемые импорты для tree shaking:

```javascript
// ✅ Хорошо - импорт только нужных компонентов
import { BaseButton, BaseInput } from '@fun-sun/ui-kit/components'

// ✅ Хорошо - импорт только нужных утилит
import { debounce, onlyCyrillicLettersMask } from '@fun-sun/ui-kit/utils'

// ❌ Плохо - импорт всего пакета
import * as FsKit from '@fun-sun/ui-kit'
```

## Доступные компоненты

### Alert

- **BaseAlert** - Компонент для отображения уведомлений

### Button

- **BaseButton** - Базовая кнопка

### Checkbox

- **BaseCheckbox** - Базовая версия чекбокса
- **BaseCheckboxCascade** - Каскадный чекбокс с поддержкой вложенных элементов

### Input

- **BaseInput** - Базовое поле ввода
- **BaseInputDate** - Поле ввода даты
- **BaseInputFloatNumber** - Поле ввода дробного числа
- **BaseInputPassword** - Поле ввода пароля
- **BaseInputPhone** - Поле ввода телефона
- **BaseInputWithDropdown** - Поле ввода с выпадающим списком
- **BaseSearchInput** - Поле поиска
- **BaseAutocompleteInput** - Поле автодополнения
- **BaseFilterInputNumber** - Поле фильтрации по числу
- **BaseFilterInputText** - Поле фильтрации по тексту
- **BaseFilterInputWithDropdown** - Поле фильтрации с выпадающим списком

### Select

- **BaseDropdownWithApi** - Выпадающий список с API
- **BaseSelect** - Базовый селект

### Droplist

- **BaseDroplist** - Выпадающий список
- **BaseRadioDroplist** - Выпадающий список с радио-кнопками
- **BaseDroplistCheckbox** - Выпадающий список с чек-кнопками
- **BaseDroplistItem** - Элемент выпадающего списка

### Range

- **BaseRange** - Базовый слайдер диапазона
- **BaseRangeDouble** - Двусторонний слайдер диапазона
- **BaseRangeTime** - Слайдер диапазона времени
- **BaseRangeMoney** - Слайдер диапазона денег
- **BaseNightsRange** - Слайдер диапазона ночей

### Pagination

- **BasePagination** - Базовая пагинация

### Calendar

- **BaseCalendar** - Базовый календарь
- **BaseDatePicker** - Компонент выбора даты

### Radio

- **BaseRadioGroup** - Группа радио-кнопок

### Switcher

- **BaseSwitcher** - Переключатель

### Tabs

- **BaseSegmentedControl** - Сегментированный контрол (вкладки)
- **BaseSegmentedControlFixed** - Фиксированный сегментированный контрол

### Loaders

- **BaseProgressBar** - Линейный индикатор прогресса
- **BaseProgressBarSearch** - Индикатор прогресса поиска
- **BaseProgressRadial** - Круговой индикатор прогресса

### Skeleton

- **BaseSkeleton** - Компонент скелетона для загрузки

### Textarea

- **BaseTextarea** - Базовое текстовое поле
- **BaseTextareaDropzone** - Текстовое поле с зоной перетаскивания файлов

### Tooltip

- **BaseTooltip** - Всплывающая подсказка

### Wrappers

- **BaseWrapperDetails** - Компонент деталей (раскрывающийся блок)
- **BaseWrapperPopup** - Обертка для попапа
- **BaseMobileBottomSheet** - Мобильная нижняя панель

### Icons

- **BaseIcon** - Базовый компонент иконки
- **BaseIconCounter** - Иконка со счетчиком
- **BaseIconIndicator** - Иконка с индикатором

### Gallery

- **BaseGallery** - Базовый компонент галереи
- **BaseGalleryWrapper** - Компонент галереи на весь экран

### Other

- **BaseNumberStepper** - Степпер для чисел
- **BaseDocument** - Компонент документа
- **BaseChart** - Компонент графика
- **BaseChartSlide** - Слайд графика
- **BaseNotResult** - Компонент для отображения отсутствия результатов

## Доступные утилиты

### forFunctions.js

- **debounce** - Функция для задержки выполнения функции

### masks.js

- **onlyCyrillicLettersMask** - Маска только для кириллических букв
- **onlyCyrillicLettersAndNumbersMask** - Маска для кириллических букв и цифр
- **cyrillicDashSpaceMask** - Маска для кириллицы, дефиса и пробелов
- **cyrillicLatinMask** - Маска для кириллических и латинских букв
- **russianPassportMask** - Маска для российского паспорта (#### - ### ###)
- **russianInternationalPassportMask** - Маска для заграничного паспорта (## - #######)

### sizes.js

- **bytesToSize** - Функция для преобразования байт в читаемый размер файла

### uuid.js

- **isValidUUID** - Валидация uuid
- **generateSafeUUID** - Функция для генерпции uuid

### bodyLock.js

- **bodyLock** - Функция для блокировки скролла
- **bodyUnlock** - Функция для разблокировки скролла
- **isMobile** - Функция для проверки на мобильную версию

### calculation.js

- **sortByNumericField** - Функция для сортировки массива по числовому полю

### date.js

- **toJSONLocal** - Преобразование даты в формат YYYY-MM-DD с возможностью добавления/вычитания дней
- **generateMonths** - Генерация массива месяцев с днями для календаря

### securityCheck.js

- **validateFilename** - Валидация имени файла
- **validateFileContent** - Валидация содержимого файла
- **validateFileSize** - Валидация размера файла
- **prepareForDownload** - Подготовка файла к скачиванию
- **sanitizeFilename** - Очистка имени файла от опасных символов
- **extractFilenameFromContentDisposition** - Извлечение имени файла из заголовков
- **parseFileNameFromHeaders** - Парсинг имени файла из заголовков ответа

## Доступные директивы

- **vOutside** - Директива для обработки кликов вне элемента
