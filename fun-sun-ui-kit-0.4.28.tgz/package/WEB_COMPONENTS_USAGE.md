# Использование Web Components из @fun-sun/ui-kit

## Описание

Web Components версии Vue компонентов позволяют использовать компоненты из пакета `@fun-sun/ui-kit` в любом HTML-приложении без необходимости использования Vue фреймворка. Все web components имеют префикс `web-` в имени тега.

## Установка

```bash
npm install @fun-sun/ui-kit
```

## Требования:

- наличие установленного пакета style
- наличие sprite.svg файла в папке public
- Web Components требуют Vue runtime для работы. Убедитесь, что Vue подключен в вашем проекте:

### Рекомендуемый способ: ES-модуль версия Vue

Используйте ES-модуль версию Vue из CDN через import maps:

```html
<script type="importmap">
    {
        "imports": {
            "vue": "https://unpkg.com/vue@3/dist/vue.esm-browser.js"
        }
    }
</script>
```

### Альтернативный способ: Модульная система

Если вы используете сборщик (Vite, Webpack и т.д.):

```javascript
import Vue from 'vue'
```

### 📦 Vue в devDependencies при использовании сборщиков

Если вы используете сборщик (Vite, Webpack и т.д.) и хотите загружать Vue из CDN в браузере, **Vue всё равно должен быть установлен в `devDependencies`**:

```json
{
    "devDependencies": {
        "vue": "^3.5.26"
    }
}
```

**Зачем нужен Vue в devDependencies:**

1. **Для работы Vite во время разработки:**
    - Vite использует Vue из `node_modules` для предварительной сборки зависимостей (`optimizeDeps`)
    - Это позволяет Vite корректно разрешать импорты из `@fun-sun/ui-kit` при анализе зависимостей
    - Необходим для корректной работы с web-components модулями

2. **Для работы `@vitejs/plugin-vue`:**
    - Плагин может использовать типы Vue для TypeScript
    - Необходим для корректной работы плагина во время сборки

3. **Для соответствия peer dependencies:**
    - `@fun-sun/ui-kit` требует Vue как peer dependency (обязательный)
    - Vue в `devDependencies` удовлетворяет этому требованию

**Важно:**

- Vue в `devDependencies` **не попадает в production bundle** (если настроен `external: ['vue']` в конфигурации сборщика)
- Vue в `devDependencies` **не устанавливается** при `npm install --production`
- В браузере Vue загружается из CDN через import maps, а не из bundle
- Vue в `devDependencies` нужен **только для инструментов сборки**, а не для runtime

### 🔌 Настройка @vitejs/plugin-vue для работы с Web Components

Если вы используете Vite в качестве сборщика, **необходимо установить и настроить `@vitejs/plugin-vue`**:

```bash
npm install --save-dev @vitejs/plugin-vue
```

**Зачем нужен `@vitejs/plugin-vue`:**

1. **Корректная обработка HTML-шаблонов:**
    - Плагин указывает Vite, что теги с префиксом `web-` являются custom elements, а не Vue компонентами
    - Без плагина Vite может пытаться обрабатывать `<web-alert>`, `<web-button>` и т.д. как Vue компоненты, что вызовет ошибки при сборке

2. **Предотвращение ошибок компиляции:**
    - Плагин предотвращает попытки Vite компилировать web-components как Vue компоненты
    - Обеспечивает корректную обработку HTML-файлов с web-components

3. **Поддержка TypeScript:**
    - Плагин может использовать типы Vue для TypeScript (если используется)

**Важно:**

- Плагин нужен **даже если в проекте нет `.vue` файлов**
- Плагин используется только для настройки обработки custom elements в HTML
- Плагин не влияет на размер production bundle (это dev-зависимость)

**Пример конфигурации Vite:**

```javascript
// vite.config.js
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
    plugins: [
        vue({
            template: {
                compilerOptions: {
                    // Указываем Vite, что все теги с префиксом web- являются custom elements
                    isCustomElement: (tag) => tag.includes('web-'),
                },
            },
        }),
    ],
    build: {
        rollupOptions: {
            // Исключаем Vue из bundle - используем из CDN
            external: ['vue'],
        },
    },
})
```

**Что делает настройка `isCustomElement`:**

- Функция `isCustomElement: (tag) => tag.includes('web-')` сообщает Vite, что все теги, содержащие `web-` в имени, должны обрабатываться как нативные custom elements
- Это предотвращает попытки Vite компилировать их как Vue компоненты
- Позволяет корректно собирать HTML-файлы с web-components

**Можно ли обойтись без плагина?**

Теоретически можно, если:

- В проекте нет `.vue` файлов
- HTML-файлы не содержат Vue-синтаксиса (только web-components)

Но **рекомендуется оставить плагин**, потому что:

- ✅ Плагин легковесный и не влияет на production bundle
- ✅ Гарантирует корректную обработку web-components в HTML
- ✅ Предотвращает потенциальные проблемы при сборке
- ✅ Упрощает конфигурацию и делает её более явной

### ⚠️ Важно: Проблема с глобальной версией Vue

Если вы используете глобальную версию Vue (`vue.global.js`), модуль web-components не сможет автоматически разрешить импорт `vue`, так как он ожидает ES-модуль. В этом случае необходимо создать файл-обертку (см. раздел "Использование в HTML").

## Использование

### Подключение стилей

Для корректного отображения компонентов необходимо подключить стили:

```html
<link
    rel="stylesheet"
    href="./node_modules/@fun-sun/ui-kit/web-components.css"
/>
```

Или в JavaScript:

```javascript
import '@fun-sun/ui-kit/web-components.css'
```

**Важно:** Web Components используют Shadow DOM в отключенном режиме (`shadowRoot: false` для Vue 3.5+), что позволяет использовать внешние стили из `@fun-sun/ui-tokens`.

Для корректной работы утилитарных классов (например, `radius-8`, `p-16`, `bg-red-2`, `flex`, `Heading_4` и т.д.) необходимо **дополнительно подключить стили из `@fun-sun/ui-tokens`** в вашем проекте:

```javascript
// В вашем проекте
import '@fun-sun/ui-tokens/dist/style.css'
import '@fun-sun/ui-kit/web-components.css'
```

Или в HTML:

```html
<link
    rel="stylesheet"
    href="./node_modules/@fun-sun/ui-tokens/dist/style.css"
/>
<link
    rel="stylesheet"
    href="./node_modules/@fun-sun/ui-kit/web-components.css"
/>
```

### Использование в HTML

После подключения стилей и Vue, вы можете использовать web components напрямую в HTML:

#### Вариант 1: Vue через ES-модуль из CDN (рекомендуется)

**Используйте ES-модуль версию Vue из CDN** вместо глобальной версии. Это позволяет избежать проблем с разрешением импортов:

```html
<!DOCTYPE html>
<html>
<head>
    <!-- Подключаем стили -->
    <link rel="stylesheet" href="./node_modules/@fun-sun/ui-tokens/dist/style.css">
    <link rel="stylesheet" href="./node_modules/@fun-sun/ui-kit/web-components.css">

    <!-- Используем import maps для Vue из CDN как ES-модуль -->
    <script type="importmap">
    {
        "imports": {
            "vue": "https://unpkg.com/vue@3/dist/vue.esm-browser.js"
        }
    }
    </script>
</head>
<body>
    <!-- Используем компоненты в HTML с пропсами и событиями -->

    <!-- Alert с пропсом iconName и несколькими слотами -->
    <web-alert icon-name="common--info"></web-alert>
        <span slot="title">Важное уведомление</span>
        <span slot="subtitle">Это пример использования компонента с пропсами</span>
        <span slot="text">Дополнительный текст уведомления с подробной информацией</span>
    </web-alert>

    <!-- Input с пропсами и обработчиками событий -->
    <web-input
        id="name-input"
        label="Имя пользователя"
        placeholder="Введите ваше имя"
        name="username"
        maxlen="50"
        required="true"
        disabled="false"
    ></web-input>

    <!-- Button с пропсами и обработчиком события -->
    <web-button
        id="submit-btn"
        disabled="false"
        loading="false"
    >
        Отправить форму
    </web-button>

    <!-- Импортируем web-components -->
    <script type="module">
        import '@fun-sun/ui-kit/web-components'

        // Обработка событий после загрузки DOM
        document.addEventListener('DOMContentLoaded', () => {
            // Обработка события input для web-input
            const nameInput = document.getElementById('name-input')
            if (nameInput) {
                nameInput.addEventListener('input', (event) => {
                    console.log('Введенное значение:', event.detail)
                })

                nameInput.addEventListener('focus', () => {
                    console.log('Поле ввода получило фокус')
                })

                nameInput.addEventListener('blur', (event) => {
                    console.log('Поле ввода потеряло фокус', event.detail)
                })

                nameInput.addEventListener('submit', () => {
                    console.log('Нажата клавиша Enter в поле ввода')
                })
            }

            // Обработка события click для web-button
            const submitBtn = document.getElementById('submit-btn')
            if (submitBtn) {
                submitBtn.addEventListener('click', () => {
                    console.log('Кнопка нажата')
                    // Можно программно изменить пропсы
                    submitBtn.setAttribute('loading', 'true')
                    submitBtn.setAttribute('disabled', 'true')
                })
            }
        })
    </script>
</body>
</html>
```

#### Вариант 2: Vue через глобальный скрипт (требует обертку)

Если вы используете глобальную версию Vue (`vue.global.js`), необходимо создать файл-обертку для разрешения импорта `vue`:

**1. Создайте файл `vue-wrapper.js` в корне проекта:**

```javascript
// vue-wrapper.js
// Обертка для Vue из CDN, чтобы он был доступен как ES-модуль
if (typeof window !== 'undefined' && window.Vue) {
    export const defineCustomElement = window.Vue.defineCustomElement
    export default window.Vue
} else {
    throw new Error('Vue должен быть загружен через CDN перед импортом этого модуля')
}
```

**2. Используйте в HTML:**

```html
<!DOCTYPE html>
<html>
    <head>
        <link
            rel="stylesheet"
            href="./node_modules/@fun-sun/ui-kit/web-components.css"
        />

        <!-- Подключаем Vue из CDN (глобальная версия) -->
        <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>

        <!-- Настраиваем import maps для разрешения импорта vue -->
        <script type="importmap">
            {
                "imports": {
                    "vue": "./vue-wrapper.js"
                }
            }
        </script>

        <!-- Импортируем web-components -->
        <script
            type="module"
            src="./node_modules/@fun-sun/ui-kit/web-components"
        ></script>
    </head>
    <body>
        <!-- Используем компоненты в HTML с пропсами и событиями -->

        <!-- Alert с пропсом iconName и несколькими слотами -->
        <web-alert icon-name="common--info">
            <span slot="title">Важное уведомление</span>
            <span slot="subtitle">Это пример использования компонента с пропсами</span>
            <span slot="text">Дополнительный текст уведомления с подробной информацией</span>
        </web-alert>

        <!-- Input с пропсами и обработчиками событий -->
        <web-input
            id="name-input"
            label="Имя пользователя"
            placeholder="Введите ваше имя"
            name="username"
            maxlen="50"
            required="true"
            disabled="false"
        ></web-input>

        <!-- Button с пропсами и обработчиком события -->
        <web-button
            id="submit-btn"
            disabled="false"
            loading="false"
        >
            Отправить форму
        </web-button>

        <!-- Обработка событий -->
        <script>
            // Обработка событий после загрузки DOM
            document.addEventListener('DOMContentLoaded', () => {
                // Обработка события input для web-input
                const nameInput = document.getElementById('name-input')
                if (nameInput) {
                    nameInput.addEventListener('input', (event) => {
                        console.log('Введенное значение:', event.detail)
                    })

                    nameInput.addEventListener('focus', () => {
                        console.log('Поле ввода получило фокус')
                    })

                    nameInput.addEventListener('blur', (event) => {
                        console.log('Поле ввода потеряло фокус', event.detail)
                    })

                    nameInput.addEventListener('submit', () => {
                        console.log('Нажата клавиша Enter в поле ввода')
                    })
                }

                // Обработка события click для web-button
                const submitBtn = document.getElementById('submit-btn')
                if (submitBtn) {
                    submitBtn.addEventListener('click', () => {
                        console.log('Кнопка нажата')
                        // Можно программно изменить пропсы
                        submitBtn.setAttribute('loading', 'true')
                        submitBtn.setAttribute('disabled', 'true')
                    })
                }
            })
        </script>
    </body>
</html>
```

**Важно:**

- **Рекомендуется использовать Вариант 1** (ES-модуль версию Vue), так как она не требует дополнительных файлов
- При использовании глобальной версии Vue (`vue.global.js`) необходимо создать файл-обертку и настроить import maps
- Import maps поддерживаются в современных браузерах (Chrome 89+, Edge 89+, Safari 16.4+)

### Использование в JavaScript/TypeScript

#### Автоматическая регистрация (рекомендуется)

**Все компоненты регистрируются автоматически** при импорте модуля. Дополнительная регистрация не требуется:

```javascript
// Просто импортируем модуль - все компоненты регистрируются автоматически
import '@fun-sun/ui-kit/web-components'

// Теперь можно использовать компоненты в HTML
// <web-alert>...</web-alert>
// <web-button>...</web-button>
```

#### Импорт конкретных компонентов (если нужен доступ к классам)

Если вам нужен доступ к классам компонентов или константам с именами тегов:

```javascript
import { WebAlert, WebButton, ALERT_TAG_NAME, BUTTON_TAG_NAME } from '@fun-sun/ui-kit/web-components'

// Компоненты уже зарегистрированы автоматически при импорте
// Ручная регистрация нужна только в особых случаях (например, для переопределения существующего компонента)
```

#### Использование в Vue приложении

Web Components можно использовать в Vue приложениях:

```vue
<template>
    <web-alert>
        <span slot="title">Заголовок</span>
    </web-alert>
</template>

<script setup>
// Подключаем стили
import '@fun-sun/ui-tokens/dist/style.css'
import '@fun-sun/ui-kit/web-components.css'

// Импорт модуля автоматически регистрирует все компоненты
import '@fun-sun/ui-kit/web-components'
</script>
```

Или можно импортировать только нужные компоненты:

```vue
<script setup>
import '@fun-sun/ui-tokens/dist/style.css'
import '@fun-sun/ui-kit/web-components.css'

import { WebAlert } from '@fun-sun/ui-kit/web-components'
</script>
```

## Доступные компоненты

Все Vue компоненты из пакета доступны как Web Components с префиксом `web-`:

- `BaseAlert` → `WebAlert` → `<web-alert>`
- `BaseButton` → `WebButton` → `<web-button>`
- `BaseInput` → `WebInput` → `<web-input>`
- `BaseCheckbox` → `WebCheckbox` → `<web-checkbox>`
- `BaseTooltip` → `WebTooltip` → `<web-tooltip>`
- И так далее...

**Важно:** В именах Web Components префикс "Base" удален. Например, `BaseAlert` становится `WebAlert`, а не `WebBaseAlert`.

Полный список компонентов можно найти в файле `src/components/index.js` или `src/web-components/index.js`.

## Пропсы и события

Web Components поддерживают все пропсы и события оригинальных Vue компонентов. Пропсы передаются как HTML атрибуты:

```html
<web-input
    placeholder="Введите текст"
    disabled="false"
></web-input>
```

**Примечание:** В обычном HTML используйте строковые значения для атрибутов. Булевы значения передаются как строки `"true"` или `"false"`, числа как строки `"50"`.

События можно слушать через стандартные DOM события:

```javascript
const input = document.querySelector('web-input')
input.addEventListener('input', (event) => {
    console.log('Значение изменено:', event.detail)
})
```

## Генерация Web Components

Web Components генерируются автоматически при сборке пакета командой:

```bash
npm run build:package
```

Или вручную:

```bash
# Генерация файлов web components
npm run generate:web-components

# Сборка web components
npm run build:web-components
```

## Примечания

- Web Components требуют Vue runtime для работы. Vue должен быть подключен в вашем проекте ДО использования web components
- **Shadow DOM отключен** (`shadowRoot: false`) для возможности использования внешних стилей из `@fun-sun/ui-tokens`
- Все компоненты имеют префикс `web-` в имени тега
- В именах Web Components префикс "Base" удален (например, `WebAlert` вместо `WebBaseAlert`)
- Константы имен тегов также без префикса "BASE" (например, `ALERT_TAG_NAME` вместо `BASEALERT_TAG_NAME`)
